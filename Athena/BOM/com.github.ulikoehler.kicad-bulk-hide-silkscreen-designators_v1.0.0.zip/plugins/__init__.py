#!/usr/bin/env python
from .bulk_hide_silkscreen_designators_action import BulkHideSilkscreenDesignators
BulkHideSilkscreenDesignators().register() # Instantiate and register to Pcbnew